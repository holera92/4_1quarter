public enum StateOfChopstick {
    FREE,
    BUSY
}
